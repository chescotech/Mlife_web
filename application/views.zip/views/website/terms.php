<style>
    .content {
        width: 100%;
        height: 100vh;
        background-color: #FCFCFC;
    }

    .container {
        width: 100%;
        height: 100%;
        text-align: center;
    }

    .login {
        width: 50%;
        margin: auto;
        background-color: #fff;
        border: 1px solid #ccc;
        padding: 15px;
        border-radius: 10px;
        margin-top: 50px;
        align-items: center;
    }
</style>

<div class="content">
    <div class="container">
        <h4 style="padding-top: 50px;">Terms and Conditions</h4>

        <br> <br>
        
        <embed src="assets_web/docs/tncs.pdf" frameborder="0" width="100%" height="100%">

    </div>
</div>