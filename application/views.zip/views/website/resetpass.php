<div marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #fff;" leftmargin="0">
    <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#fff" style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
        <tr>
            <td>
                <table style="background-color: #fff; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr style="border:none">
                        <td style="text-align:center; border:none">
                            <a href="https://rakeshmandal.com" title="logo" target="_blank">
                                <img width="300" src="assets_web/img/mlifelogo.jpg" title="logo" alt="logo">
                            </a>
                        </td>
                    </tr>

                    <tr style="border:none">
                        <td >
                            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                <tr style="border:none">
                                    <td style="height:40px; border:none">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding:0 35px;">
                                        <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;">You have
                                            requested to reset your password</h1>
                                        <label style="color: #fff">Enter Agent Code *</label>
                                        <input style="border: 1px solid #ccc" type="text" class="form-control" name="AgentCode" id="AgentCode" placeholder="Agent Code" required autocomplete="false">
                                        <span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span>
                                        <p style="color:#455056; font-size:15px;line-height:24px; margin:0;">
                                            We cannot simply send you your old password. A unique code to reset your
                                            password will been sent to you. To reset your password, click the
                                            following button send the code.
                                        </p>
                                        <a href="javascript:void(0);" style="background:#20e277;text-decoration:none !important; font-weight:500; margin-top:35px; color:#fff;text-transform:uppercase; font-size:14px;padding:10px 24px;display:inline-block;border-radius:50px;">
                                            Send Code
                                        </a>
                                    </td>
                                </tr>
                                <tr style="border:none">
                                    <td style="height:40px; border:none">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    <tr style="border:none">
                        <td style="height:20%; border:none">
                            <div style="height:20%;"></div>
                        </td>
                    </tr>

                </table>
            </td>
        </tr>
    </table>
</div>