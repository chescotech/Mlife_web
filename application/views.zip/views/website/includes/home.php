<div class="content-wrapper">
    <!-- slider -->
    <?php @$this->load->view('website/includes/slider'); ?>
    <!-- Service Section -->
    <?php @$this->load->view('website/includes/service'); ?>
    <!-- /Service Section -->
</div>

<?php @$this->load->view('website/includes/appointment'); ?>
<!-- /.appointment content -->