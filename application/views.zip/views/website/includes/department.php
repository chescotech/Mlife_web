<div class="department">
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                <div class="section-title" style="margin-top: 15px;">
                    <h2>
                        We’ve kept things simple
                    </h2>
                    <p>
                        As part of our commitment to our customers, 
                        we’ve created a policy document that is simple and easy
                        to understand, so that you can be confident knowing what you are and are not covered for.
                    </p>
                </div>
            </div>
        </div>
        
    </div>
</div>