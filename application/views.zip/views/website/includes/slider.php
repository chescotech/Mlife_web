           <div class="header-slider header-slider-preloader" id="header-slider">
               <div style="height: 170px; 
                    width: 100%; 
                    background-color: #304060; 
                    color: #fff; 
                    text-align: center;
                    padding: 10px;
               ">
                   <h2> Domestic Travel Insurance </h2>
                   <p style="color:#fff"> It provides key travel benefits in case of an emergency.</p>
               </div>
           </div>