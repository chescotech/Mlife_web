<div class="partners-content">
    
</div>